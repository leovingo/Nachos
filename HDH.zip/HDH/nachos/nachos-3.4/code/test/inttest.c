#include "syscall.h"

int main()
{
    int a=ReadInt();
    PrintInt(a);
    return 0;	
}
